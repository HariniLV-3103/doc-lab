#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

typedef struct {
    char op[15], arg1[20], arg2[20], res[20], raw[100];
    int folded;
} Quad;

Quad q[300];
int n = 0;

int is_number(char *s) {
    if (*s == '\0') return 0;
    if (*s == '-' || *s == '+') s++;
    while (*s) {
        if (!isdigit(*s)) return 0;
        s++;
    }
    return 1;
}

void parse_line(char *line) {
    char a[20], b[20], c[20], d[20], e[20];
    int cnt = sscanf(line, "%s %s %s %s %s", a, b, c, d, e);
    if (cnt <= 0 || line[0] == '-') return;

    strcpy(q[n].raw, line);
    q[n].folded = 0;
    q[n].op[0] = q[n].arg1[0] = q[n].arg2[0] = q[n].res[0] = '\0';

    if (a[strlen(a)-1] == ':') {
        strcpy(q[n].op, "label"); a[strlen(a)-1] = '\0'; strcpy(q[n].res, a);
    } else if (strcmp(a, "goto") == 0) {
        strcpy(q[n].op, "goto"); strcpy(q[n].res, b);
    } else if (strcmp(a, "ifFalse") == 0) {
        strcpy(q[n].op, "ifFalse"); strcpy(q[n].arg1, b); strcpy(q[n].res, d);
    } else if (strcmp(a, "return") == 0) {
        strcpy(q[n].op, "return"); strcpy(q[n].arg1, b);
    } else if (cnt == 3 && strcmp(b, "=") == 0) {
        strcpy(q[n].op, "="); strcpy(q[n].res, a); strcpy(q[n].arg1, c);
    } else if (cnt == 4 && strcmp(b, "=") == 0) {
        strcpy(q[n].op, c); strcpy(q[n].res, a); strcpy(q[n].arg1, d);
    } else if (cnt == 5 && strcmp(b, "=") == 0) {
        strcpy(q[n].op, d); strcpy(q[n].res, a); strcpy(q[n].arg1, c); strcpy(q[n].arg2, e);
    }
    n++;
}

// Helper to find if a variable was previously folded into a constant value
char* get_constant_value(char *var, int current_idx) {
    if (is_number(var)) return var;
    for (int i = 0; i < current_idx; i++) {
        if (strcmp(q[i].res, var) == 0 && strcmp(q[i].op, "=") == 0 && is_number(q[i].arg1)) {
            return q[i].arg1;
        }
    }
    return NULL;
}

int main() {
    char line[100];
    while (fgets(line, sizeof(line), stdin)) {
        line[strcspn(line, "\r\n")] = 0;
        parse_line(line);
    }

    printf("--- PART D: OPTIMIZED TAC (CONSTANT FOLDING) ---\n");
    
    for (int i = 0; i < n; i++) {
        // Handle binary operations: res = arg1 op arg2
        if (strlen(q[i].op) > 0 && strcmp(q[i].op, "=") != 0 && 
            strcmp(q[i].op, "label") != 0 && strcmp(q[i].op, "goto") != 0 && 
            strcmp(q[i].op, "ifFalse") != 0 && strcmp(q[i].op, "return") != 0) {
            
            char *val1 = get_constant_value(q[i].arg1, i);
            char *val2 = get_constant_value(q[i].arg2, i);

            if (val1 && val2) {
                int v1 = atoi(val1);
                int v2 = atoi(val2);
                int res_val = 0;
                int computed = 1;

                if (strcmp(q[i].op, "+") == 0) res_val = v1 + v2;
                else if (strcmp(q[i].op, "-") == 0) res_val = v1 - v2;
                else if (strcmp(q[i].op, "*") == 0) res_val = v1 * v2;
                else if (strcmp(q[i].op, "/") == 0 && v2 != 0) res_val = v1 / v2;
                else computed = 0;

                if (computed) {
                    // Print the folded direct assignment instead of temporary variable math
                    printf("%s = %d\n", q[i].res, res_val);
                    // Mark preceding instructions that computed this temp as folded/handled
                    q[i].folded = 1;
                    continue;
                }
            }
        }

        // Handle direct assignments of constants or propagation
        if (strcmp(q[i].op, "=") == 0) {
            char *val = get_constant_value(q[i].arg1, i);
            if (val) {
                printf("%s = %s\n", q[i].res, val);
                continue;
            }
        }

        // If it's a temporary variable assignment that got fully folded, skip printing its raw form
        int skip = 0;
        if (q[i].res[0] == 't') {
            // Check if this temp result was used in a folded expression
            for (int j = i + 1; j < n; j++) {
                if ((strcmp(q[j].arg1, q[i].res) == 0 || strcmp(q[j].arg2, q[i].res) == 0)) {
                    char *v1 = get_constant_value(q[j].arg1, j);
                    char *v2 = get_constant_value(q[j].arg2, j);
                    if (v1 && v2) skip = 1;
                }
            }
        }

        if (!skip) {
            printf("%s\n", q[i].raw);
        }
    }

    return 0;
}